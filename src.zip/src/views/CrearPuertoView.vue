<template>
  <div class="form-container">
    <h2>Adicionar Puerto</h2>
    <form @submit.prevent="saveItem" class="form-grid">
      <!-- Campo Nombre del Puerto -->
      <div class="form-group">
        <label for="nombre_puerto">Nombre del Puerto:<span style="color: red;">*</span></label>
        <input type="text" style="padding: 3px;" v-model="nombre_puerto" required />
      </div>

      <!-- Campo País -->
      <div class="form-group">
        <label for="pais">País:<span style="color: red;">*</span></label>
        <select v-model="pais" style="padding: 5px;" required>
          <option v-for="item in paisOptions" :key="item.id" :value="item.id">{{ item.nombre_pais }}</option>
        </select>
      </div>

      <!-- Campo Provincia -->
      <div class="form-group">
        <label for="provincia">Provincia:</label>
        <select v-model="provincia" style="padding: 5px;">
          <option v-for="item in provinciaOptions" :key="item.id" :value="item.id">{{ item.nombre_provincia }}</option>
        </select>
      </div>

      <!-- Campo Servicio Portuario -->
      <div class="form-group">
        <label for="servicio_portuario">Servicio Portuario:</label>
        <select v-model="servicio_portuario" style="padding: 5px;">
          <option v-for="item in servicioPortuarioOptions" :key="item.id" :value="item.id">{{ item.nombre_territorio }}</option>
        </select>
      </div>

      <!-- Campo Latitud -->
      <div class="form-group">
        <label for="latitud">Latitud:</label>
        <input type="text" style="padding: 3px;" v-model="latitud" required />
      </div>

      <!-- Campo Longitud -->
      <div class="form-group">
        <label for="longitud">Longitud:</label>
        <input type="text" style="padding: 3px;" v-model="longitud" required />
      </div>

      <div class="form-buttons">
        <button type="button" @click="confirmCancel" style="color:white;text-decoration:none">Cancelar</button>
        <button>Aceptar</button>
      </div>
    </form>
  </div>
</template>

<style scoped>
.form-container {
  max-width: 600px; /* Ajusta el ancho máximo del contenedor */
  margin: 50px; /* Centra el contenedor */
  padding: 20px;
  background-color: #f9f9f9;
  border-radius: 8px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

h2 {
  font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
  text-align: left;
  margin-bottom: 20px;
  font-size: 20px;
}

.form-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr); /* 4 columnas de igual tamaño */
  gap: 15px; /* Espacio entre los elementos */
}

.form-group {
  text-align: left;
  width: 260px;
  display: flex;
  flex-direction: column;
  gap: 5px;
  font-size: 14px;
}

label {
  font-weight: bold;
}

input, select {
  padding: 5px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

.form-buttons {
  grid-column: span 2; /* Los botones ocupan las 4 columnas */
  display: flex;
  justify-content: end;
  font-size: 15px;
  margin-top: 20px;
}

button {
  margin-left: 10px;
  padding: 5px 15px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-weight: bold;
}

button[type="button"] {
  background-color: #007bff;
  color: white;
}

button[type="submit"] {
  margin-left: 15px;
  background-color: #007bff;
  color: white;
}
</style>


<script>
import Swal from 'sweetalert2';
import axios from 'axios';

export default {
  data() {
    return {
      nombre_puerto: '',
      pais: '',
      provincia: '',
      servicio_portuario: '',
      latitud: '',
      longitud: '',
      paisOptions: [],
      provinciaOptions: [],
      servicioPortuarioOptions: []
    };
  },
  mounted() {
    this.fetchOptions();
  },
  methods: {
    confirmCancel() {
    Swal.fire({
    title: '¿Está seguro de que quiere cancelar la operación?',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    cancelmButtonText: 'Cancelar',
    confirmButtonText: 'Aceptar'
  }).then((result) => {
    if (result.isConfirmed) {
      window.history.back();
    }
  });
},
    validateForm() {
      const nombrePuertoRegex = /^[A-Z][a-zA-ZáéíóúÁÉÍÓÚñÑäëöüÄËÏÜ ]{2,99}$/;
      const latitudRegex = /^[\d\.]+$/;
      const longitudRegex = /^[\d\.]+$/;
      let errorMessage = '';

      if (!nombrePuertoRegex.test(this.nombre_puerto)) {
        errorMessage += 'El campo "Nombre del Puerto" comienza con mayúscula y admite letras y espacios. Tamaño mínimo 3 caracteres y máximo 100 caracteres.\n';
      }
      if (!latitudRegex.test(this.latitud)) {
        errorMessage += 'El campo "Latitud" admite únicamente números y puntos.\n';
      }
      if (!longitudRegex.test(this.longitud)) {
        errorMessage += 'El campo "Longitud" admite únicamente números y puntos.\n';
      }

      if (errorMessage) {
        Swal.fire({
          icon: 'error',
          title: 'Error de validación',
          text: errorMessage,
        });
        return false; // Detener el envío del formulario
      }

      return true; // El formulario es válido
    },
    async fetchOptions() {
      try {
        const [paisResponse, provinciaResponse, servicioPortuarioResponse] = await Promise.all([
          axios.get('/api/paises/'),
          axios.get('/api/provincias/'),
          axios.get('/api/territorios/')
        ]);

        this.paisOptions = paisResponse.data;
        this.provinciaOptions = provinciaResponse.data;
        this.servicioPortuarioOptions = servicioPortuarioResponse.data;
      } catch (error) {
        console.error('Error al obtener las opciones:', error);
      }
    },
    async saveItem() {
      if (!this.validateForm()) {
        return; // Detener el envío si la validación falla
      }

      this.$store.commit('setIsLoading', true);
      const puerto = {
        nombre_puerto: this.nombre_puerto,
        pais: this.pais,
        provincia: this.provincia,
        servicio_portuario: this.servicio_portuario,
        latitud: this.latitud,
        longitud: this.longitud,
      };

      try {
        await axios.post('/api/puertos/', puerto);
        this.$router.push('/Puertos');
        Swal.fire('Agregado!', 'El puerto ha sido insertado exitosamente.', 'success');
      } catch (error) {
        console.error('Error al agregar el puerto:', error);
        Swal.fire('Error', 'Hubo un error al agregar el puerto.', 'error');
      } finally {
        this.$store.commit('setIsLoading', false);
      }
    },
  },
};
</script>